function x()
    --[[
function qwe() end

s = {x={},w={}}

]]
end --[[before comma 1]] --[[after comma 1]] -- after comma 2
--[[before comma 1]] --[[after comma 1]] -- after comma 2
--[[before comma 1]] --[[after comma 1]] -- after comma 2

funca()
--[[c1]]
function --[[c2]] func1 --[[c3]] ( --[[c4]] ) --[[c5]]
    print --[[c6]] ( --[[c7]] "1" --[[c8]] ) --[[c9]] ; --[[c10]] --[[c11]] --[[c12]]
end --[[c13]]
--[[c1]]
function --[[c2]] func2 --[[c3]] ( --[[c4]] ) --[[c5]]
    print --[[c6]] ( --[[c7]] "2" --[[c8]] ) --[[c9]] ; --[[c10]] --[[c11]] --[[c12]]
end --[[c13]]
