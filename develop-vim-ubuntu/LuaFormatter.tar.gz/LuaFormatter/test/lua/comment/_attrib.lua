local --[[ c1 ]] x --[[ c2 ]] <const> --[[ c3 ]] = --[[ c4 ]] {}
