function x()
    s:append(s:append("wwwwwwwwwww"):append("wwwwwwwwwwwwwwwwww")):append(
        s:append("wwwwwwwwwwwwwww"):append("wwwwwwwwwwwwwwwwwwwwww")):append(
        s:append("wwwwwwwwwwwwwww"):append("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww"))
        :append(s:append("ww"):append("wwwwwwwwwwwwwww"):append("ww")
                    :append("wwww"))
end
