xxxxxxxxxxxxxxxxxx:xxxxxxxxxxxxxxxxxxx(
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww"
)
xxxxxxxxxxxxxxxxxx:xxxxxxxxxxxxxxxxxxxxxx(
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww"
)
