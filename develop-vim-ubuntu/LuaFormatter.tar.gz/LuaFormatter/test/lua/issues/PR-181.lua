do
	function function_with_long_name(long_parameter_1, long_parameter_2, long_parameter_3, long_parameter_4, long_parameter_5)
		foobar()
	end
end