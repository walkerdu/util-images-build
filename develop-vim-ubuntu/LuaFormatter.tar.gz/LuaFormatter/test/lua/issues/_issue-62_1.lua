array = {
    variable1, variable2, variable3, variable4, variable5, variable6, variable7,
    variable8, variable9, variable10
}

kv_table = {
    key1 = variable1, key2 = variable2, key3 = variable3, key4 = variable4,
    key5 = variable5, key6 = variable6, key7 = variable7, key8 = variable8,
    key9 = variable9, key10 = variable10
}

mixed_table = {
    key1 = variable1, key2 = variable2, key3 = variable3, variable4, variable5,
    variable6, variable7, variable8, variable9, variable10
}
