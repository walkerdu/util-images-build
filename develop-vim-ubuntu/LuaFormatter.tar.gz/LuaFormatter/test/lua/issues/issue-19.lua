auto(update(path.base,
            {
    aaaaaaaa = 'aa',
    dddddddddddddddddddddddddddd = i,
    dddddddddddddddd = i
}))
auto(update(path.base, {
    aaaaaaaa = 'aaaaaaaaaaaaaaaaaaaaaaaaaa',
    dddddddddddddddddddddddddddd = i,
    dddddddddddddddd = i
}))
