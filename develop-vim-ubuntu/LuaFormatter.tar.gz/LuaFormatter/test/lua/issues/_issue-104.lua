-- print(reallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariable)
-- print(reallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariable)
print(
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
)

print("a")

print( -- boo
    reallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariable -- bar
) -- foo

print(
    reallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariablereallylongvariable,
    1245
) -- bar

xxx(
    xxx,
    xxxxxx
) -- foobar

function W()
  print(1)
  print(2)
end

-- LuaFormatter off
xxx(
   xxx,
   xxxxxx
) -- foobar
-- LuaFormatter on
