addEvent("onPlayerJoin", true)
