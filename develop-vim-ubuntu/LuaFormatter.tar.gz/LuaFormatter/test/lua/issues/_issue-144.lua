local a = {"one", "one", "one", "one", "one", "one", "one", "one", "one", "one", "one", "one", "one", "one"}

local some_list = {
  ['A'] = true,
  ['B'] = true,
  ['C'] = true,
  ['D'] = true,
  ['E'] = true
}

local tests = {['test1'] = true, ['test2'] = false, ['test3'] = true}

local more_tests = {
  ['test1'] = true,
  ['test2'] = true,
  ['test3'] = false,
  ['test4'] = false,
  ['test5'] = true
}

local Something = {['A'] = true, ['B'] = true}
