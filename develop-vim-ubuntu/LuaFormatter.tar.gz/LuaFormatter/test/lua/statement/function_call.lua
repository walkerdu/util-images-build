
print("simple")
a,b,c = pcall(print,"1","2")
print(1,2,"str",{},function() end,(function() return {1,2,3} end)());

(function() end)():a():b():c()
q = x.q[2](1):y()"2"(x)

require "abc"
require [[qwe]]

x = require "abc" "x"

xx.xx:xx().q:w "a""b""c"
xx "a"[[b]]"c"