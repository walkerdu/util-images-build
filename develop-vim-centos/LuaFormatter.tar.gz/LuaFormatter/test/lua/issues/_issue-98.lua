test = {
  image = "test",
  list = {
    {
      ref = "testRef",
      tags = {"tagTest"},
      time = 10,

      materials = {{materialId = 123, count = 10}}
    }
  }
}
