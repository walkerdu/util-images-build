local function foo(one, two, three, four, five, six, seven, eight, nine, ten, eleven, twelve, thirteen)
  return 5
end