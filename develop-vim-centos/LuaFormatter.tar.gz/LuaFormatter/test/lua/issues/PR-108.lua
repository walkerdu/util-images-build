function someLongLongLongLongLongFunc(
    aaaaaaaaaa, bbbbbbbbbb, cccccccccc,
        dddddddddd, eeeeeeeeee, ffffffffff,
        gggggggggg)
    someFunctionCall()
    anotherFunctionCall()
end
