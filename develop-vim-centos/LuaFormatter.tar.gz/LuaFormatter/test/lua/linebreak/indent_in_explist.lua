xxxxxxxxxxxxxxxx.xxxxxxxxxxxxxxxx(
    "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww",
    "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww",
    "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww",
    "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww"
)

varvarvarvarvarvarvarvarvarvarvar = "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww", "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww", "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww", "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwww"

do
    do
        arr:add(first_arg .. 'flags' .. 'flags' .. 'flags' .. 'flags' .. 'flags',
            second_arg.foo(xxxxxxxx .. '.' .. xxxxxxxx .. 'flags') or another_arg.foo(xxxxxxxx .. 'flags'))
    end
end

return wwwwwwwwwwwwwwwwwwwwwww, "wwwwwwwwwwwwwww" .. "wwwwwwwwwwwww" .. "wwwwwwww" .. "wwwwwwwwwwwww" .. "wwwwwwww" .. "wwwwwwwwwwwww" .. "wwwwwwww" .. "wwwwwwwwwwwww" .. "wwwwwww"
